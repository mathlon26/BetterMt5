def MT5Error(Exception):
    pass